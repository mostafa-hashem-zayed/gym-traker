# SYNTRA — Fitness Tracker

A premium, black & white fitness tracking Progressive Web App with an
AI-powered coaching assistant. Users track workouts, body weight, and
hydration, follow structured training programs, and get instant fitness
guidance from SYNTRA Coach.

## Run & Operate

- `pnpm --filter @workspace/syntra run dev` — run the SYNTRA web app (requires `PORT`, `BASE_PATH`)
- `pnpm --filter @workspace/api-server run dev` — run the API server (SYNTRA Coach backend only)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- Required env (frontend, see `artifacts/syntra/.env.example`): `VITE_FIREBASE_API_KEY`, `VITE_FIREBASE_AUTH_DOMAIN`, `VITE_FIREBASE_PROJECT_ID`, `VITE_FIREBASE_STORAGE_BUCKET`, `VITE_FIREBASE_MESSAGING_SENDER_ID`, `VITE_FIREBASE_APP_ID`
- Required env (API server, see `artifacts/api-server/.env.example`): `AI_INTEGRATIONS_OPENROUTER_BASE_URL`, `AI_INTEGRATIONS_OPENROUTER_API_KEY`

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- Frontend: React 18 + Vite 7, Tailwind CSS, Radix UI, Wouter, Framer Motion
- Auth & data: Firebase Auth + Firestore (client-direct, no custom backend for app data)
- API server: Express 5 — used exclusively for the SYNTRA Coach chat proxy (SSE streaming to OpenRouter)
- AI: OpenRouter via `@workspace/integrations-openrouter-ai` (model: `meta-llama/llama-3.3-70b-instruct`)
- DB scaffold: PostgreSQL + Drizzle ORM (`@workspace/db`) is present in the monorepo template but **not currently used** by SYNTRA — kept for future features
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (API server), Vite (frontend)

## Where things live

- `artifacts/syntra/` — the SYNTRA React/Vite PWA (pages, components, Firebase client, Firestore helpers)
- `artifacts/syntra/src/lib/firebase.ts` — Firebase app/auth/Firestore init (reads config from `VITE_FIREBASE_*` env vars)
- `artifacts/syntra/firestore.rules` — reference copy of the deployed Firestore security rules
- `artifacts/api-server/src/routes/coach.ts` — SYNTRA Coach SSE chat endpoint (`POST /api/coach`)
- `artifacts/syntra/src/components/CoachChat.tsx` — floating AI chat UI (SSE client, streaming render)
- `lib/integrations-openrouter-ai/` — shared OpenRouter client used by the coach route
- Full architecture and setup docs: see the root `README.md`

## Architecture decisions

- All user-facing app data (workouts, weight, hydration, programs) lives in Firestore and is read/written directly from the client — there is no custom REST layer for this data.
- The Express API server exists solely to proxy AI chat requests to OpenRouter (keeps the API key server-side and enables SSE streaming); it is not a general backend.
- SYNTRA Coach is intentionally scope-limited: it answers fitness/form/recovery questions but never generates full workout programs or writes to the database.
- Firebase client config is loaded from `VITE_*` environment variables (not hardcoded) so the repo can be published/open-sourced safely.

## Product

- Firebase email/password auth, Dashboard, Weight tracking, Hydration tracking, Workout History with streaks, structured Programs with per-day Workout pages and demo videos, installable PWA shell, and the SYNTRA Coach floating AI chat assistant.

## User preferences

- Repo is prepared for professional/public GitHub distribution: README, LICENSE (MIT), CONTRIBUTING.md, CHANGELOG.md, and `.env.example` files are maintained at the root and per-artifact.

## Gotchas

- Never hardcode Firebase or OpenRouter credentials in source — use the `.env.example` files as the contract and Replit secrets/`.env` for real values.
- `lib/db` requires `DATABASE_URL` at import time; only import it if you actually wire in Postgres — it is currently unused by SYNTRA.
- Vite only exposes env vars prefixed with `VITE_` to client code.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
- See root `README.md` for full installation, run, and contribution instructions
