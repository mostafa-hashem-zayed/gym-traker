# SYNTRA — Fitness Tracker

SYNTRA is a premium, black & white fitness tracking Progressive Web App. It helps
athletes log workouts, track body weight and hydration, follow structured
training programs, and get instant answers from **SYNTRA Coach** — a built-in
AI fitness assistant.

The project is a pnpm monorepo containing the SYNTRA web app, a small API
server (used only for the AI coach), and shared internal libraries.

## Features

- **Email/password authentication** via Firebase Auth
- **Workout logging** — log sets, reps, and weight per exercise, browsed by day
- **Structured training programs** with per-day exercise breakdowns and demo videos
- **Body weight tracking** with historical trend view
- **Hydration tracking** with daily goals
- **Workout history** and streak calculation
- **SYNTRA Coach** — a floating AI chat assistant (OpenRouter + Llama 3.3 70B)
  that answers fitness, form, recovery, and nutrition questions with live
  streaming responses. It intentionally does not generate full programs or
  modify your data.
- **Installable PWA** — add to home screen, offline-friendly shell
- Fully responsive, mobile-first, matte black & white design

## Technologies Used

**Frontend (`artifacts/syntra`)**
- React 18 + Vite 7 + TypeScript
- Tailwind CSS + Radix UI primitives (shadcn-style components)
- Wouter (routing), Framer Motion (animation)
- Firebase Auth + Firestore (all app data is read/written directly from the
  client — there is no custom backend for user data)
- `vite-plugin-pwa` for installable/offline support

**Backend (`artifacts/api-server`)**
- Node.js 24 + Express 5 + TypeScript
- Used exclusively to proxy streaming chat requests to OpenRouter for
  SYNTRA Coach (`POST /api/coach`, Server-Sent Events)
- Structured logging with Pino

**Shared libraries (`lib/*`)**
- `@workspace/integrations-openrouter-ai` — thin OpenAI-SDK-compatible client
  configured for OpenRouter
- `@workspace/db` — Drizzle ORM + Postgres scaffold provided by the monorepo
  template. Not currently wired into SYNTRA's data flow (Firestore is the
  source of truth for user data); kept for future use.
- `@workspace/api-zod`, `@workspace/api-client-react`, `@workspace/api-spec` —
  OpenAPI-first contract tooling for any future REST endpoints

**Tooling**
- pnpm workspaces, esbuild, Orval (OpenAPI codegen), Prettier

## Project Structure

```
.
├── artifacts/
│   ├── syntra/              # React + Vite PWA (the SYNTRA app)
│   │   ├── src/
│   │   │   ├── components/  # UI components (incl. shadcn-style primitives in ui/)
│   │   │   ├── contexts/    # AuthContext (Firebase auth state)
│   │   │   ├── data/        # Static program/exercise data
│   │   │   ├── hooks/       # Reusable React hooks
│   │   │   ├── lib/         # Firebase client, Firestore helpers, utils
│   │   │   └── pages/       # Route-level pages (Dashboard, Weight, etc.)
│   │   ├── public/          # Static assets, PWA icons
│   │   ├── firestore.rules  # Reference copy of the deployed Firestore rules
│   │   └── .env.example
│   ├── api-server/          # Express API — only serves the AI coach endpoint
│   │   ├── src/
│   │   │   ├── routes/      # coach.ts (SSE chat), health.ts
│   │   │   ├── middlewares/
│   │   │   └── lib/
│   │   └── .env.example
│   └── mockup-sandbox/      # Internal component-preview sandbox (dev tooling)
├── lib/                     # Shared workspace packages (see above)
├── scripts/                 # Repo-level utility scripts
├── pnpm-workspace.yaml      # Workspace + dependency catalog
└── tsconfig*.json           # Shared TypeScript project references
```

## Installation

**Prerequisites:** Node.js 24+, pnpm 10+, a Firebase project (Auth + Firestore
enabled), and an OpenRouter API key (only needed for the AI coach feature).

```bash
git clone <this-repo-url>
cd <repo-directory>
pnpm install
```

Set up environment variables:

```bash
cp artifacts/syntra/.env.example artifacts/syntra/.env
cp artifacts/api-server/.env.example artifacts/api-server/.env
```

Fill in your Firebase web app config in `artifacts/syntra/.env` (found in the
Firebase Console under Project Settings → General → Your apps), and your
OpenRouter key in `artifacts/api-server/.env`.

Firestore security rules used by this project are documented for reference in
`artifacts/syntra/firestore.rules` — deploy them via the Firebase Console or
CLI to your own project.

## How to Run the Project

Each artifact runs as its own service. In development:

```bash
# API server (SYNTRA Coach backend) — requires PORT to be set
pnpm --filter @workspace/api-server run dev

# SYNTRA web app — requires PORT and BASE_PATH to be set
pnpm --filter @workspace/syntra run dev
```

> On Replit, both services are already wired up as workflows and read `PORT`
> / `BASE_PATH` automatically. Outside Replit, export those variables
> yourself before running the commands above (e.g. `PORT=5173 BASE_PATH=/`).

Other useful commands:

```bash
pnpm run typecheck                                   # typecheck everything
pnpm run build                                        # typecheck + build all packages
pnpm --filter @workspace/api-spec run codegen          # regenerate API hooks/schemas
```

## Screenshots

> _Add screenshots or GIFs of the app here._

| Landing | Dashboard | SYNTRA Coach |
| --- | --- | --- |
| _placeholder_ | _placeholder_ | _placeholder_ |

## Future Improvements

- Persist SYNTRA Coach conversation history per user (currently stateless per session)
- Add automated tests (unit + end-to-end)
- Add nutrition/meal logging
- Social features (sharing progress, leaderboards)
- Wearable/device integrations (Apple Health, Google Fit)
- Dark/light theme toggle (currently dark-only by design)

## License

This project is licensed under the [MIT License](LICENSE).

## Author

Built by Mohamed. Contributions welcome — see [CONTRIBUTING.md](CONTRIBUTING.md).
