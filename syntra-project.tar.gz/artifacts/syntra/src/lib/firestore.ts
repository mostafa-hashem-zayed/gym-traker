import { db } from "./firebase";
import { 
  collection, 
  doc, 
  setDoc, 
  addDoc, 
  getDocs, 
  query, 
  orderBy, 
  deleteDoc, 
  limit, 
  where,
  Timestamp,
  getDoc
} from "firebase/firestore";

export interface WeightLog {
  id?: string;
  weight: number;
  unit: "kg" | "lbs";
  date: string;
  createdAt: Timestamp;
}

export interface WorkoutLog {
  id?: string;
  programId: string;
  dayId: string;
  dayName: string;
  completedExercises: string[];
  date: string;
  createdAt: Timestamp;
}

export interface HydrationLog {
  id?: string;
  amount: number;
  goal: number;
  date: string;
  createdAt: Timestamp;
}

// Weight
export async function addWeightLog(userId: string, data: Omit<WeightLog, "id" | "createdAt">) {
  const collRef = collection(db, `users/${userId}/weightLogs`);
  await addDoc(collRef, {
    ...data,
    createdAt: Timestamp.now()
  });
}

export async function getWeightLogs(userId: string): Promise<WeightLog[]> {
  const q = query(collection(db, `users/${userId}/weightLogs`), orderBy("date", "desc"));
  const snap = await getDocs(q);
  return snap.docs.map(d => ({ id: d.id, ...d.data() } as WeightLog));
}

export async function deleteWeightLog(userId: string, logId: string) {
  await deleteDoc(doc(db, `users/${userId}/weightLogs`, logId));
}

// Workout
export async function addWorkoutLog(userId: string, data: Omit<WorkoutLog, "id" | "createdAt">) {
  const collRef = collection(db, `users/${userId}/workoutLogs`);
  await addDoc(collRef, {
    ...data,
    createdAt: Timestamp.now()
  });
}

export async function getWorkoutLogs(userId: string, maxLimit?: number): Promise<WorkoutLog[]> {
  let q = query(collection(db, `users/${userId}/workoutLogs`), orderBy("date", "desc"));
  if (maxLimit) {
    q = query(q, limit(maxLimit));
  }
  const snap = await getDocs(q);
  return snap.docs.map(d => ({ id: d.id, ...d.data() } as WorkoutLog));
}

// Hydration
export async function addHydrationLog(userId: string, data: Omit<HydrationLog, "id" | "createdAt">) {
  const docRef = doc(db, `users/${userId}/hydrationLogs`, data.date);
  await setDoc(docRef, {
    ...data,
    createdAt: Timestamp.now()
  }, { merge: true });
}

export async function getHydrationLog(userId: string, date: string): Promise<HydrationLog | null> {
  const docRef = doc(db, `users/${userId}/hydrationLogs`, date);
  const snap = await getDoc(docRef);
  if (snap.exists()) {
    return { id: snap.id, ...snap.data() } as HydrationLog;
  }
  return null;
}

export async function getHydrationHistory(userId: string): Promise<HydrationLog[]> {
  const q = query(collection(db, `users/${userId}/hydrationLogs`), orderBy("date", "desc"), limit(7));
  const snap = await getDocs(q);
  return snap.docs.map(d => ({ id: d.id, ...d.data() } as HydrationLog)).reverse();
}
