import React from "react";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { PROGRAMS } from "@/data/programs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export default function Programs() {
  return (
    <div className="container mx-auto px-4 py-12 max-w-6xl space-y-12">
      <div className="text-center max-w-2xl mx-auto space-y-4">
        <h1 className="text-4xl md:text-5xl font-black tracking-tight uppercase">Training Programs</h1>
        <p className="text-secondary-foreground font-medium text-lg">
          Structured routines designed for progressive overload and measurable results.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {PROGRAMS.map((prog, i) => (
          <motion.div
            key={prog.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="h-full"
          >
            <Link href={`/programs/${prog.id}`}>
              <Card className="glass-card h-full hover:bg-white/[0.06] transition-colors cursor-pointer group border-white/10 hover:border-white/20">
                <CardHeader>
                  <div className="flex justify-between items-start mb-2">
                    <Badge variant="outline" className="bg-black/50 text-white border-white/20 tracking-widest uppercase text-[10px] font-bold py-1 px-3">
                      {prog.difficulty}
                    </Badge>
                    <span className="text-xs font-bold tracking-widest text-secondary-foreground uppercase">
                      {prog.frequency}
                    </span>
                  </div>
                  <CardTitle className="text-2xl font-black tracking-tight">{prog.name}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-secondary-foreground font-medium mb-6 line-clamp-2">
                    {prog.description}
                  </p>
                  <div className="flex items-center text-sm font-bold tracking-widest uppercase text-white group-hover:text-white transition-colors">
                    View Program <span className="ml-2 group-hover:translate-x-1 transition-transform">→</span>
                  </div>
                </CardContent>
              </Card>
            </Link>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
