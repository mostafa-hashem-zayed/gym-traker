import React from "react";
import { Link, useRoute } from "wouter";
import { motion } from "framer-motion";
import { PROGRAMS } from "@/data/programs";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Calendar, Dumbbell } from "lucide-react";

export default function ProgramDetail() {
  const [, params] = useRoute("/programs/:programId");
  const program = PROGRAMS.find(p => p.id === params?.programId);

  if (!program) {
    return <div className="p-8 text-center font-bold">Program not found</div>;
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl space-y-12">
      <Link href="/programs" className="inline-flex items-center text-xs font-bold tracking-widest uppercase text-secondary-foreground hover:text-white transition-colors">
        <ArrowLeft className="w-4 h-4 mr-2" /> Back to Programs
      </Link>

      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
        <div className="flex items-center gap-3">
          <Badge className="bg-white text-black font-bold uppercase tracking-widest text-[10px] px-3 py-1">
            {program.difficulty}
          </Badge>
          <span className="text-xs font-bold tracking-widest text-secondary-foreground uppercase">
            {program.frequency}
          </span>
        </div>
        <h1 className="text-5xl md:text-6xl font-black tracking-tight uppercase">{program.name}</h1>
        <p className="text-lg text-secondary-foreground font-medium max-w-2xl leading-relaxed">
          {program.description}
        </p>
      </motion.div>

      <div>
        <h2 className="text-sm font-bold tracking-widest uppercase text-secondary-foreground mb-6">Program Days</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {program.workouts.map((day, i) => (
            <motion.div
              key={day.id}
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: i * 0.05 }}
            >
              <Link href={`/programs/${program.id}/${day.id}`}>
                <Card className="glass-card hover:bg-white/[0.06] transition-colors cursor-pointer group">
                  <CardContent className="p-6 flex items-center justify-between">
                    <div>
                      <h3 className="font-bold text-xl mb-1 group-hover:text-white transition-colors">{day.name}</h3>
                      <div className="flex items-center text-xs font-bold tracking-widest text-secondary-foreground uppercase">
                        <Dumbbell className="w-3 h-3 mr-1.5" />
                        {day.exercises.length} Exercises
                      </div>
                    </div>
                    <div className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center group-hover:bg-white/10 transition-colors">
                      <span className="font-bold text-lg">→</span>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}
