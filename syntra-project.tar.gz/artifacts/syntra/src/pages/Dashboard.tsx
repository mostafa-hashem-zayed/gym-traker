import React, { useEffect, useState } from "react";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { format } from "date-fns";
import { LineChart, Line, ResponsiveContainer, XAxis, YAxis, Tooltip } from "recharts";
import { Droplet, Dumbbell, Scale, AlertTriangle } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { getWeightLogs, getHydrationLog, getWorkoutLogs, WeightLog, HydrationLog, WorkoutLog } from "@/lib/firestore";
import StatsCard from "@/components/StatsCard";
import HydrationCircle from "@/components/HydrationCircle";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

function parseLocalDate(dateStr: string): Date {
  return new Date(dateStr + "T12:00:00");
}

function calcStreak(logs: { date: string }[]): number {
  let streak = 0;
  const checkDate = new Date();
  const todayStr = format(checkDate, "yyyy-MM-dd");
  const hasToday = logs.some((l) => l.date === todayStr);
  if (!hasToday) checkDate.setDate(checkDate.getDate() - 1);
  for (let i = 0; i < 365; i++) {
    const dStr = format(checkDate, "yyyy-MM-dd");
    if (logs.some((l) => l.date === dStr)) {
      streak++;
      checkDate.setDate(checkDate.getDate() - 1);
    } else {
      break;
    }
  }
  return streak;
}

export default function Dashboard() {
  const { user } = useAuth();
  const [weightLogs, setWeightLogs] = useState<WeightLog[]>([]);
  const [hydration, setHydration] = useState<HydrationLog | null>(null);
  const [workoutLogs, setWorkoutLogs] = useState<WorkoutLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [firestoreError, setFirestoreError] = useState(false);

  useEffect(() => {
    if (!user) return;
    setLoading(true);
    setFirestoreError(false);

    async function loadData() {
      const today = format(new Date(), "yyyy-MM-dd");
      try {
        const [wLogs, hLog, woLogs] = await Promise.all([
          getWeightLogs(user!.uid),
          getHydrationLog(user!.uid, today),
          getWorkoutLogs(user!.uid),
        ]);
        setWeightLogs(wLogs);
        setHydration(hLog);
        setWorkoutLogs(woLogs);
      } catch (err: any) {
        if (err?.code === "permission-denied") {
          setFirestoreError(true);
        }
        console.error(err);
      } finally {
        setLoading(false);
      }
    }

    loadData();
  }, [user]);

  if (loading) {
    return (
      <div className="flex-1 flex items-center justify-center font-bold tracking-widest uppercase text-secondary-foreground">
        Loading...
      </div>
    );
  }

  if (firestoreError) {
    return (
      <div className="flex-1 flex items-center justify-center px-4">
        <div className="max-w-lg w-full glass-card rounded-xl p-8 border border-white/10 text-center space-y-6">
          <AlertTriangle className="w-12 h-12 mx-auto text-yellow-400" />
          <div>
            <h2 className="text-xl font-black uppercase tracking-tight mb-2">Firestore Access Denied</h2>
            <p className="text-secondary-foreground text-sm font-medium leading-relaxed">
              Your Firebase project's Security Rules are blocking data access. Paste these rules into your{" "}
              <strong className="text-white">Firebase Console → Firestore → Rules</strong> tab and publish them:
            </p>
          </div>
          <pre className="text-left bg-black/60 border border-white/10 rounded-lg p-4 text-xs text-green-400 overflow-x-auto whitespace-pre-wrap">
{`rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{userId}/{document=**} {
      allow read, write: if request.auth != null
        && request.auth.uid == userId;
    }
  }
}`}
          </pre>
          <Button
            className="bg-white text-black font-bold uppercase tracking-widest hover:bg-white/90"
            onClick={() => window.location.reload()}
          >
            Reload after saving rules
          </Button>
        </div>
      </div>
    );
  }

  const latestWeight = weightLogs.length > 0 ? weightLogs[0].weight : null;
  const weightUnit = weightLogs.length > 0 ? weightLogs[0].unit : "";
  const streak = calcStreak(workoutLogs);

  const chartData = [...weightLogs]
    .reverse()
    .slice(-7)
    .map((w) => ({
      date: format(parseLocalDate(w.date), "MMM d"),
      weight: w.weight,
    }));

  const timeOfDay = new Date().getHours();
  let greeting = "Good evening";
  if (timeOfDay < 12) greeting = "Good morning";
  else if (timeOfDay < 17) greeting = "Good afternoon";

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl space-y-8">
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="text-3xl font-black tracking-tight mb-2">
          {greeting},{" "}
          <span className="text-secondary-foreground">{user?.displayName || "Athlete"}</span>
        </h1>
        <p className="text-secondary-foreground font-medium uppercase tracking-widest text-xs">Overview</p>
      </motion.div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <StatsCard
          label="Current Weight"
          value={latestWeight !== null ? latestWeight : "—"}
          subValue={latestWeight !== null ? weightUnit : ""}
        />
        <StatsCard
          label="Hydration Progress"
          value={hydration ? `${(hydration.amount / 1000).toFixed(1)}L` : "0.0L"}
          subValue={hydration ? `/ ${(hydration.goal / 1000).toFixed(1)}L` : "/ 2.5L"}
        />
        <StatsCard label="Workout Streak" value={streak} subValue="Days" />
      </div>

      <div className="flex flex-wrap gap-4 pt-4">
        <Link href="/weight">
          <Button className="bg-white text-black hover:bg-white/90 font-bold uppercase tracking-widest text-xs h-12 px-6">
            <Scale className="w-4 h-4 mr-2" /> Log Weight
          </Button>
        </Link>
        <Link href="/hydration">
          <Button
            variant="outline"
            className="border-white/20 hover:bg-white/10 font-bold uppercase tracking-widest text-xs h-12 px-6"
          >
            <Droplet className="w-4 h-4 mr-2" /> Log Water
          </Button>
        </Link>
        <Link href="/programs">
          <Button
            variant="outline"
            className="border-white/20 hover:bg-white/10 font-bold uppercase tracking-widest text-xs h-12 px-6"
          >
            <Dumbbell className="w-4 h-4 mr-2" /> Start Workout
          </Button>
        </Link>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 pt-4">
        <Card className="glass-card lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-sm font-bold uppercase tracking-widest text-secondary-foreground">
              Weight Trend
            </CardTitle>
          </CardHeader>
          <CardContent>
            {chartData.length > 1 ? (
              <div className="h-[300px] w-full mt-4">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={chartData}>
                    <XAxis
                      dataKey="date"
                      stroke="#a0a0a0"
                      fontSize={12}
                      tickLine={false}
                      axisLine={false}
                      dy={10}
                    />
                    <YAxis
                      domain={["auto", "auto"]}
                      stroke="#a0a0a0"
                      fontSize={12}
                      tickLine={false}
                      axisLine={false}
                      dx={-10}
                    />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "#111",
                        borderColor: "rgba(255,255,255,0.1)",
                        borderRadius: "8px",
                      }}
                      itemStyle={{ color: "#fff", fontWeight: "bold" }}
                    />
                    <Line
                      type="monotone"
                      dataKey="weight"
                      stroke="#ffffff"
                      strokeWidth={3}
                      dot={{ r: 4, fill: "#000", stroke: "#fff", strokeWidth: 2 }}
                      activeDot={{ r: 6, fill: "#fff" }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            ) : (
              <div className="h-[300px] flex items-center justify-center text-sm font-medium text-secondary-foreground text-center">
                Not enough data.
                <br />
                Log your weight to see trends.
              </div>
            )}
          </CardContent>
        </Card>

        <div className="space-y-6 flex flex-col">
          <Card className="glass-card flex-1 flex flex-col items-center justify-center py-8">
            <CardHeader className="w-full text-center pb-0">
              <CardTitle className="text-sm font-bold uppercase tracking-widest text-secondary-foreground">
                Today's Hydration
              </CardTitle>
            </CardHeader>
            <CardContent className="flex items-center justify-center pt-8">
              <HydrationCircle amount={hydration?.amount || 0} goal={hydration?.goal || 2500} size={220} />
            </CardContent>
          </Card>
        </div>
      </div>

      <div className="pt-4">
        <h3 className="text-sm font-bold uppercase tracking-widest text-secondary-foreground mb-4">
          Recent Workouts
        </h3>
        {workoutLogs.length > 0 ? (
          <div className="space-y-3">
            {workoutLogs.slice(0, 3).map((log, i) => (
              <motion.div
                key={log.id}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.1 }}
              >
                <div className="glass-card rounded-lg p-4 flex items-center justify-between">
                  <div>
                    <div className="font-bold">{log.dayName}</div>
                    <div className="text-sm text-secondary-foreground font-medium">
                      {log.completedExercises.length} exercises completed
                    </div>
                  </div>
                  <div className="text-sm font-bold tracking-wider text-secondary-foreground uppercase">
                    {format(parseLocalDate(log.date), "MMM d, yyyy")}
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        ) : (
          <div className="glass-card rounded-lg p-8 text-center text-sm font-medium text-secondary-foreground">
            No workouts logged yet.
          </div>
        )}
      </div>
    </div>
  );
}
