import React, { useEffect, useState } from "react";
import { format } from "date-fns";
import { useAuth } from "@/contexts/AuthContext";
import { getWorkoutLogs, WorkoutLog } from "@/lib/firestore";
import StatsCard from "@/components/StatsCard";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dumbbell, AlertTriangle } from "lucide-react";

function parseLocalDate(dateStr: string): Date {
  return new Date(dateStr + "T12:00:00");
}

function calcStreak(logs: { date: string }[]): number {
  let streak = 0;
  const checkDate = new Date();
  const todayStr = format(checkDate, "yyyy-MM-dd");
  const hasToday = logs.some((l) => l.date === todayStr);
  if (!hasToday) checkDate.setDate(checkDate.getDate() - 1);
  for (let i = 0; i < 365; i++) {
    const dStr = format(checkDate, "yyyy-MM-dd");
    if (logs.some((l) => l.date === dStr)) {
      streak++;
      checkDate.setDate(checkDate.getDate() - 1);
    } else {
      break;
    }
  }
  return streak;
}

export default function WorkoutHistory() {
  const { user } = useAuth();
  const [logs, setLogs] = useState<WorkoutLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [firestoreError, setFirestoreError] = useState(false);

  useEffect(() => {
    if (!user) return;
    async function load() {
      try {
        const data = await getWorkoutLogs(user!.uid);
        setLogs(data);
      } catch (err: any) {
        if (err?.code === "permission-denied") setFirestoreError(true);
        console.error(err);
      } finally {
        setLoading(false);
      }
    }
    load();
  }, [user]);

  if (loading)
    return (
      <div className="p-8 text-center uppercase tracking-widest font-bold text-secondary-foreground">
        Loading...
      </div>
    );

  if (firestoreError) {
    return (
      <div className="flex-1 flex items-center justify-center px-4">
        <div className="max-w-lg w-full glass-card rounded-xl p-8 border border-white/10 text-center space-y-6">
          <AlertTriangle className="w-12 h-12 mx-auto text-yellow-400" />
          <div>
            <h2 className="text-xl font-black uppercase tracking-tight mb-2">Firestore Access Denied</h2>
            <p className="text-secondary-foreground text-sm font-medium leading-relaxed">
              Update your Firestore Security Rules in{" "}
              <strong className="text-white">Firebase Console → Firestore → Rules</strong>:
            </p>
          </div>
          <pre className="text-left bg-black/60 border border-white/10 rounded-lg p-4 text-xs text-green-400 overflow-x-auto whitespace-pre-wrap">
{`match /users/{userId}/{document=**} {
  allow read, write: if request.auth != null
    && request.auth.uid == userId;
}`}
          </pre>
          <Button
            className="bg-white text-black font-bold uppercase tracking-widest hover:bg-white/90"
            onClick={() => window.location.reload()}
          >
            Reload after saving rules
          </Button>
        </div>
      </div>
    );
  }

  const streak = calcStreak(logs);

  return (
    <div className="container mx-auto px-4 py-8 max-w-5xl space-y-8">
      <div>
        <h1 className="text-4xl font-black tracking-tight uppercase mb-2">Workout History</h1>
        <p className="text-sm font-bold tracking-widest text-secondary-foreground uppercase">
          Training Logs
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <StatsCard label="Total Workouts" value={logs.length} />
        <StatsCard label="Current Streak" value={streak} subValue="Days" />
      </div>

      <Card className="glass-card border-white/10 overflow-hidden">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader className="bg-black/40">
              <TableRow className="border-white/10 hover:bg-transparent">
                <TableHead className="font-bold tracking-widest uppercase text-xs">Date</TableHead>
                <TableHead className="font-bold tracking-widest uppercase text-xs">Program & Day</TableHead>
                <TableHead className="font-bold tracking-widest uppercase text-xs text-right">
                  Exercises
                </TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {logs.length === 0 ? (
                <TableRow className="border-transparent hover:bg-transparent">
                  <TableCell
                    colSpan={3}
                    className="h-32 text-center text-secondary-foreground font-medium"
                  >
                    No workouts logged yet. Head to Programs to start your first workout.
                  </TableCell>
                </TableRow>
              ) : (
                logs.map((log) => (
                  <TableRow key={log.id} className="border-white/5 hover:bg-white/5">
                    <TableCell className="font-medium whitespace-nowrap">
                      {format(parseLocalDate(log.date), "MMM d, yyyy")}
                    </TableCell>
                    <TableCell>
                      <div className="font-bold text-white">{log.dayName}</div>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="inline-flex items-center text-sm font-bold bg-white/10 px-3 py-1 rounded-full">
                        <Dumbbell className="w-3 h-3 mr-2" />
                        {log.completedExercises.length}
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </Card>
    </div>
  );
}
