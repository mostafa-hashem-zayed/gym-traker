import React from "react";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

export default function Home() {
  return (
    <div className="w-full flex flex-col">
      {/* Hero */}
      <section className="min-h-[80vh] flex flex-col items-center justify-center text-center px-4 py-20">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="max-w-4xl mx-auto space-y-8"
        >
          <h1 className="text-6xl md:text-8xl font-black tracking-tighter uppercase leading-[0.9]">
            Track. <br className="md:hidden" />
            <span className="text-secondary-foreground">Train.</span> <br className="md:hidden" />
            Transform.
          </h1>
          <p className="text-xl md:text-2xl text-secondary-foreground max-w-2xl mx-auto font-medium">
            The uncompromising digital companion for serious athletes. Track weight, hydration, and training programs with precision.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-8">
            <Link href="/signup">
              <Button size="lg" className="w-full sm:w-auto h-14 px-8 text-lg font-bold tracking-wide uppercase bg-white text-black hover:bg-white/90">
                Get Started
              </Button>
            </Link>
            <Link href="/programs">
              <Button size="lg" variant="outline" className="w-full sm:w-auto h-14 px-8 text-lg font-bold tracking-wide uppercase border-white/20 hover:bg-white/5">
                Browse Programs
              </Button>
            </Link>
          </div>
        </motion.div>
      </section>

      {/* Stats Strip */}
      <section className="border-y border-white/5 bg-[#111111]">
        <div className="container mx-auto px-4 py-12 flex flex-wrap justify-center gap-12 md:gap-24 text-center">
          <div>
            <div className="text-4xl font-black mb-1">4</div>
            <div className="text-sm font-bold tracking-widest text-secondary-foreground uppercase">Programs</div>
          </div>
          <div>
            <div className="text-4xl font-black mb-1">20+</div>
            <div className="text-sm font-bold tracking-widest text-secondary-foreground uppercase">Exercises</div>
          </div>
          <div>
            <div className="text-4xl font-black mb-1">Real-time</div>
            <div className="text-sm font-bold tracking-widest text-secondary-foreground uppercase">Sync</div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-24 px-4 container mx-auto">
        <h2 className="text-3xl font-black tracking-tight text-center mb-16 uppercase">Precision Tracking</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl mx-auto">
          {[
            { title: "Workout Tracking", desc: "Follow structured programs and log sets seamlessly." },
            { title: "Weight Progress", desc: "Monitor your bodyweight trends with clear visualizations." },
            { title: "Hydration", desc: "Set daily goals and ensure optimal fluid intake." },
            { title: "Programs", desc: "Access premium hypertrophy and strength routines." }
          ].map((feature, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
            >
              <Card className="glass-card h-full">
                <CardContent className="p-6">
                  <h3 className="text-lg font-bold tracking-wide uppercase mb-3">{feature.title}</h3>
                  <p className="text-secondary-foreground font-medium">{feature.desc}</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Footer CTA */}
      <section className="py-24 px-4 text-center border-t border-white/5 bg-gradient-to-b from-transparent to-[#050505]">
        <h2 className="text-4xl font-black tracking-tighter uppercase mb-8">Ready to start?</h2>
        <Link href="/signup">
          <Button size="lg" className="h-14 px-12 text-lg font-bold tracking-wide uppercase bg-white text-black hover:bg-white/90 shadow-[0_0_40px_rgba(255,255,255,0.1)]">
            Join Syntra
          </Button>
        </Link>
      </section>
    </div>
  );
}
