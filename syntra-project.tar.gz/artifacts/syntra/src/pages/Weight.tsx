import React, { useEffect, useState } from "react";
import { format, subDays } from "date-fns";
import { motion } from "framer-motion";
import { LineChart, Line, ResponsiveContainer, XAxis, YAxis, Tooltip } from "recharts";
import { Trash2, AlertTriangle } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { getWeightLogs, addWeightLog, deleteWeightLog, WeightLog } from "@/lib/firestore";
import StatsCard from "@/components/StatsCard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

function parseLocalDate(dateStr: string): Date {
  return new Date(dateStr + "T12:00:00");
}

export default function Weight() {
  const { user } = useAuth();
  const { toast } = useToast();

  const [logs, setLogs] = useState<WeightLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [firestoreError, setFirestoreError] = useState(false);
  const [weightInput, setWeightInput] = useState("");
  const [unit, setUnit] = useState<"kg" | "lbs">("kg");
  const [dateInput, setDateInput] = useState(format(new Date(), "yyyy-MM-dd"));
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (!user) return;
    loadData();
  }, [user]);

  async function loadData() {
    if (!user) return;
    setFirestoreError(false);
    try {
      const data = await getWeightLogs(user.uid);
      setLogs(data);
    } catch (err: any) {
      if (err?.code === "permission-denied") setFirestoreError(true);
      console.error(err);
    } finally {
      setLoading(false);
    }
  }

  async function handleAdd(e: React.FormEvent) {
    e.preventDefault();
    if (!user || !weightInput) return;

    setSubmitting(true);
    try {
      await addWeightLog(user.uid, {
        weight: parseFloat(weightInput),
        unit,
        date: dateInput,
      });
      toast({ title: "Weight logged successfully" });
      setWeightInput("");
      await loadData();
    } catch (err: any) {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    } finally {
      setSubmitting(false);
    }
  }

  async function handleDelete(id: string) {
    if (!user) return;
    try {
      await deleteWeightLog(user.uid, id);
      await loadData();
      toast({ title: "Entry deleted" });
    } catch (err: any) {
      toast({ title: "Error deleting", description: err.message, variant: "destructive" });
    }
  }

  if (loading)
    return (
      <div className="p-8 text-center uppercase tracking-widest font-bold text-secondary-foreground">
        Loading...
      </div>
    );

  if (firestoreError) {
    return (
      <div className="flex-1 flex items-center justify-center px-4">
        <div className="max-w-lg w-full glass-card rounded-xl p-8 border border-white/10 text-center space-y-6">
          <AlertTriangle className="w-12 h-12 mx-auto text-yellow-400" />
          <div>
            <h2 className="text-xl font-black uppercase tracking-tight mb-2">Firestore Access Denied</h2>
            <p className="text-secondary-foreground text-sm font-medium leading-relaxed">
              Update your Firestore Security Rules in{" "}
              <strong className="text-white">Firebase Console → Firestore → Rules</strong>:
            </p>
          </div>
          <pre className="text-left bg-black/60 border border-white/10 rounded-lg p-4 text-xs text-green-400 overflow-x-auto whitespace-pre-wrap">
{`match /users/{userId}/{document=**} {
  allow read, write: if request.auth != null
    && request.auth.uid == userId;
}`}
          </pre>
          <Button
            className="bg-white text-black font-bold uppercase tracking-widest hover:bg-white/90"
            onClick={() => window.location.reload()}
          >
            Reload after saving rules
          </Button>
        </div>
      </div>
    );
  }

  const latestWeight = logs.length > 0 ? logs[0].weight : null;
  const currentUnit = logs.length > 0 ? logs[0].unit : "kg";

  const chartData = [...logs]
    .reverse()
    .slice(-30)
    .map((w) => ({
      date: format(parseLocalDate(w.date), "MMM d"),
      weight: w.weight,
    }));

  let delta7Days: string | null = null;
  if (logs.length > 0) {
    const sevenDaysAgo = format(subDays(new Date(), 7), "yyyy-MM-dd");
    const oldLog = logs.find((l) => l.date <= sevenDaysAgo);
    if (oldLog && oldLog.unit === currentUnit) {
      const diff = logs[0].weight - oldLog.weight;
      delta7Days = diff > 0 ? `+${diff.toFixed(1)}` : diff.toFixed(1);
    }
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-5xl space-y-8">
      <div>
        <h1 className="text-4xl font-black tracking-tight uppercase mb-2">Weight Tracker</h1>
        <p className="text-sm font-bold tracking-widest text-secondary-foreground uppercase">
          Body composition
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <StatsCard
          label="Current Weight"
          value={latestWeight !== null ? latestWeight : "—"}
          subValue={latestWeight !== null ? currentUnit : ""}
        />
        <StatsCard
          label="7-Day Change"
          value={delta7Days !== null ? delta7Days : "—"}
          subValue={delta7Days !== null ? currentUnit : ""}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="glass-card lg:col-span-1 border-white/10">
          <CardContent className="p-6">
            <h3 className="text-sm font-bold uppercase tracking-widest text-secondary-foreground mb-6">
              Log New Entry
            </h3>
            <form onSubmit={handleAdd} className="space-y-4">
              <div className="space-y-2">
                <label className="text-xs font-bold tracking-widest uppercase text-secondary-foreground">
                  Weight
                </label>
                <div className="flex gap-2">
                  <Input
                    type="number"
                    step="0.1"
                    required
                    value={weightInput}
                    onChange={(e) => setWeightInput(e.target.value)}
                    className="flex-1 bg-black/50 border-white/10"
                    placeholder="0.0"
                  />
                  <div className="flex rounded-md overflow-hidden border border-white/10 bg-black/50">
                    <button
                      type="button"
                      onClick={() => setUnit("kg")}
                      className={`px-3 text-xs font-bold ${
                        unit === "kg" ? "bg-white text-black" : "text-secondary-foreground"
                      }`}
                    >
                      KG
                    </button>
                    <button
                      type="button"
                      onClick={() => setUnit("lbs")}
                      className={`px-3 text-xs font-bold ${
                        unit === "lbs" ? "bg-white text-black" : "text-secondary-foreground"
                      }`}
                    >
                      LBS
                    </button>
                  </div>
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-xs font-bold tracking-widest uppercase text-secondary-foreground">
                  Date
                </label>
                <Input
                  type="date"
                  required
                  value={dateInput}
                  onChange={(e) => setDateInput(e.target.value)}
                  className="bg-black/50 border-white/10 block w-full"
                />
              </div>
              <Button
                type="submit"
                disabled={submitting}
                className="w-full bg-white text-black font-bold uppercase tracking-widest hover:bg-white/90"
              >
                Save Entry
              </Button>
            </form>
          </CardContent>
        </Card>

        <Card className="glass-card lg:col-span-2 border-white/10">
          <CardContent className="p-6">
            <h3 className="text-sm font-bold uppercase tracking-widest text-secondary-foreground mb-6">
              Progress History
            </h3>
            {chartData.length > 1 ? (
              <div className="h-[250px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={chartData}>
                    <XAxis
                      dataKey="date"
                      stroke="#a0a0a0"
                      fontSize={12}
                      tickLine={false}
                      axisLine={false}
                      dy={10}
                    />
                    <YAxis
                      domain={["auto", "auto"]}
                      stroke="#a0a0a0"
                      fontSize={12}
                      tickLine={false}
                      axisLine={false}
                      dx={-10}
                    />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "#111",
                        borderColor: "rgba(255,255,255,0.1)",
                        borderRadius: "8px",
                      }}
                      itemStyle={{ color: "#fff", fontWeight: "bold" }}
                    />
                    <Line
                      type="monotone"
                      dataKey="weight"
                      stroke="#ffffff"
                      strokeWidth={3}
                      dot={{ r: 4, fill: "#000", stroke: "#fff", strokeWidth: 2 }}
                      activeDot={{ r: 6, fill: "#fff" }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            ) : (
              <div className="h-[250px] flex items-center justify-center text-sm font-medium text-secondary-foreground">
                Need at least 2 entries to display chart.
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <Card className="glass-card border-white/10 overflow-hidden">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader className="bg-black/40">
              <TableRow className="border-white/10 hover:bg-transparent">
                <TableHead className="font-bold tracking-widest uppercase text-xs">Date</TableHead>
                <TableHead className="font-bold tracking-widest uppercase text-xs">Weight</TableHead>
                <TableHead className="font-bold tracking-widest uppercase text-xs text-right">
                  Actions
                </TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {logs.length === 0 ? (
                <TableRow className="border-transparent hover:bg-transparent">
                  <TableCell
                    colSpan={3}
                    className="h-24 text-center text-secondary-foreground font-medium"
                  >
                    No weight data yet. Log your first entry above.
                  </TableCell>
                </TableRow>
              ) : (
                logs.map((log) => (
                  <TableRow key={log.id} className="border-white/5 hover:bg-white/5">
                    <TableCell className="font-medium">
                      {format(parseLocalDate(log.date), "MMM d, yyyy")}
                    </TableCell>
                    <TableCell className="font-bold text-lg">
                      {log.weight}{" "}
                      <span className="text-sm font-normal text-secondary-foreground">{log.unit}</span>
                    </TableCell>
                    <TableCell className="text-right">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleDelete(log.id!)}
                        className="text-secondary-foreground hover:text-red-400 hover:bg-red-400/10"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </Card>
    </div>
  );
}
