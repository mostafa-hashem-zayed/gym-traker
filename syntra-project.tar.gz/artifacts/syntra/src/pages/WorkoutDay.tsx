import React, { useState } from "react";
import { useRoute, useLocation, Link } from "wouter";
import { format } from "date-fns";
import { motion } from "framer-motion";
import { PROGRAMS } from "@/data/programs";
import { useAuth } from "@/contexts/AuthContext";
import { addWorkoutLog } from "@/lib/firestore";
import ExerciseCard from "@/components/ExerciseCard";
import WorkoutModeBar from "@/components/WorkoutModeBar";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { ArrowLeft } from "lucide-react";

export default function WorkoutDay() {
  const [, params] = useRoute("/programs/:programId/:dayId");
  const [, setLocation] = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();
  
  const program = PROGRAMS.find(p => p.id === params?.programId);
  const day = program?.workouts.find(d => d.id === params?.dayId);

  const [workoutMode, setWorkoutMode] = useState(false);
  const [completedExercises, setCompletedExercises] = useState<Set<string>>(new Set());

  if (!program || !day) {
    return <div className="p-8 text-center font-bold">Workout not found</div>;
  }

  const toggleComplete = (exerciseId: string) => {
    setCompletedExercises(prev => {
      const next = new Set(prev);
      if (next.has(exerciseId)) {
        next.delete(exerciseId);
      } else {
        next.add(exerciseId);
      }
      return next;
    });
  };

  const handleStart = () => {
    if (!user) {
      toast({ title: "Login required", description: "You must be logged in to start a workout." });
      setLocation("/login");
      return;
    }
    setWorkoutMode(true);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleFinish = async () => {
    if (!user) return;
    
    try {
      await addWorkoutLog(user.uid, {
        programId: program.id,
        dayId: day.id,
        dayName: `${program.name} - ${day.name}`,
        completedExercises: Array.from(completedExercises),
        date: format(new Date(), "yyyy-MM-dd"),
      });
      
      toast({
        title: "Workout logged!",
        description: "Great job completing your session.",
      });
      
      setLocation("/dashboard");
    } catch (err: any) {
      toast({
        title: "Error saving workout",
        description: err.message,
        variant: "destructive"
      });
    }
  };

  return (
    <>
      <div className="container mx-auto px-4 py-8 max-w-3xl space-y-8 pb-32">
        {!workoutMode && (
          <Link href={`/programs/${program.id}`} className="inline-flex items-center text-xs font-bold tracking-widest uppercase text-secondary-foreground hover:text-white transition-colors">
            <ArrowLeft className="w-4 h-4 mr-2" /> Back to {program.name}
          </Link>
        )}

        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
          <motion.div initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }}>
            <h1 className="text-4xl md:text-5xl font-black tracking-tight uppercase mb-2">{day.name}</h1>
            <p className="text-sm font-bold tracking-widest text-secondary-foreground uppercase">
              {program.name}
            </p>
          </motion.div>
          
          {!workoutMode && user && (
            <Button 
              size="lg" 
              onClick={handleStart}
              className="bg-white text-black font-bold tracking-widest uppercase hover:bg-white/90"
            >
              Start Workout
            </Button>
          )}
        </div>

        <div className="space-y-4">
          {day.exercises.map((ex, i) => (
            <motion.div
              key={ex.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
            >
              <ExerciseCard 
                exercise={ex} 
                workoutMode={workoutMode}
                completed={completedExercises.has(ex.id)}
                onToggleComplete={() => toggleComplete(ex.id)}
              />
            </motion.div>
          ))}
        </div>
      </div>

      <WorkoutModeBar
        active={workoutMode}
        progress={completedExercises.size}
        total={day.exercises.length}
        onCancel={() => {
          setWorkoutMode(false);
          setCompletedExercises(new Set());
        }}
        onFinish={handleFinish}
      />
    </>
  );
}
