import React, { useEffect, useState } from "react";
import { format, subDays } from "date-fns";
import { motion } from "framer-motion";
import { BarChart, Bar, ResponsiveContainer, XAxis, YAxis, Tooltip, Cell } from "recharts";
import { Plus, Minus, Settings2, AlertTriangle } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { getHydrationLog, addHydrationLog, getHydrationHistory, HydrationLog } from "@/lib/firestore";
import HydrationCircle from "@/components/HydrationCircle";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";

export default function Hydration() {
  const { user } = useAuth();
  const { toast } = useToast();

  const [todayLog, setTodayLog] = useState<HydrationLog | null>(null);
  const [history, setHistory] = useState<HydrationLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [firestoreError, setFirestoreError] = useState(false);

  const [goalInput, setGoalInput] = useState("2500");
  const [showGoalSettings, setShowGoalSettings] = useState(false);

  const todayStr = format(new Date(), "yyyy-MM-dd");

  useEffect(() => {
    if (!user) return;
    loadData();
  }, [user]);

  async function loadData() {
    if (!user) return;
    setFirestoreError(false);
    try {
      const [todayData, histData] = await Promise.all([
        getHydrationLog(user.uid, todayStr),
        getHydrationHistory(user.uid),
      ]);
      setTodayLog(todayData);
      if (todayData) setGoalInput(todayData.goal.toString());
      setHistory(histData);
    } catch (err: any) {
      if (err?.code === "permission-denied") setFirestoreError(true);
      console.error(err);
    } finally {
      setLoading(false);
    }
  }

  async function updateHydration(amountToAdd: number) {
    if (!user) return;
    const currentAmount = todayLog?.amount || 0;
    const currentGoal = todayLog?.goal || parseInt(goalInput) || 2500;
    const newAmount = Math.max(0, currentAmount + amountToAdd);

    try {
      await addHydrationLog(user.uid, {
        amount: newAmount,
        goal: currentGoal,
        date: todayStr,
      });
      await loadData();
    } catch (err: any) {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    }
  }

  async function updateGoal(e: React.FormEvent) {
    e.preventDefault();
    if (!user) return;
    const newGoal = parseInt(goalInput);
    if (isNaN(newGoal) || newGoal <= 0) return;

    try {
      await addHydrationLog(user.uid, {
        amount: todayLog?.amount || 0,
        goal: newGoal,
        date: todayStr,
      });
      setShowGoalSettings(false);
      await loadData();
      toast({ title: "Goal updated" });
    } catch (err: any) {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    }
  }

  if (loading)
    return (
      <div className="p-8 text-center uppercase tracking-widest font-bold text-secondary-foreground">
        Loading...
      </div>
    );

  if (firestoreError) {
    return (
      <div className="flex-1 flex items-center justify-center px-4">
        <div className="max-w-lg w-full glass-card rounded-xl p-8 border border-white/10 text-center space-y-6">
          <AlertTriangle className="w-12 h-12 mx-auto text-yellow-400" />
          <div>
            <h2 className="text-xl font-black uppercase tracking-tight mb-2">Firestore Access Denied</h2>
            <p className="text-secondary-foreground text-sm font-medium leading-relaxed">
              Update your Firestore Security Rules in{" "}
              <strong className="text-white">Firebase Console → Firestore → Rules</strong>:
            </p>
          </div>
          <pre className="text-left bg-black/60 border border-white/10 rounded-lg p-4 text-xs text-green-400 overflow-x-auto whitespace-pre-wrap">
{`match /users/{userId}/{document=**} {
  allow read, write: if request.auth != null
    && request.auth.uid == userId;
}`}
          </pre>
          <Button
            className="bg-white text-black font-bold uppercase tracking-widest hover:bg-white/90"
            onClick={() => window.location.reload()}
          >
            Reload after saving rules
          </Button>
        </div>
      </div>
    );
  }

  const currentAmount = todayLog?.amount || 0;
  const currentGoal = todayLog?.goal || 2500;

  const chartData = [];
  for (let i = 6; i >= 0; i--) {
    const d = subDays(new Date(), i);
    const dStr = format(d, "yyyy-MM-dd");
    const existing = history.find((h) => h.date === dStr);
    chartData.push({
      date: format(d, "EEE"),
      amount: existing ? existing.amount : 0,
      goal: existing ? existing.goal : currentGoal,
    });
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-5xl space-y-8 pb-20">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-4xl font-black tracking-tight uppercase mb-2">Hydration</h1>
          <p className="text-sm font-bold tracking-widest text-secondary-foreground uppercase">
            Fluid Intake
          </p>
        </div>
        <Button
          variant="outline"
          size="icon"
          className="border-white/20"
          onClick={() => setShowGoalSettings(!showGoalSettings)}
        >
          <Settings2 className="w-5 h-5 text-secondary-foreground" />
        </Button>
      </div>

      {showGoalSettings && (
        <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }}>
          <Card className="glass-card border-white/20 bg-white/5">
            <CardContent className="p-6">
              <form onSubmit={updateGoal} className="flex items-end gap-4">
                <div className="flex-1 space-y-2">
                  <label className="text-xs font-bold tracking-widest uppercase text-secondary-foreground">
                    Daily Goal (ml)
                  </label>
                  <Input
                    type="number"
                    value={goalInput}
                    onChange={(e) => setGoalInput(e.target.value)}
                    className="bg-black/50 border-white/20"
                  />
                </div>
                <Button
                  type="submit"
                  className="bg-white text-black font-bold uppercase tracking-widest hover:bg-white/90"
                >
                  Save Goal
                </Button>
              </form>
            </CardContent>
          </Card>
        </motion.div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <Card className="glass-card border-white/10 flex flex-col items-center justify-center p-8">
          <HydrationCircle amount={currentAmount} goal={currentGoal} size={280} />

          <div className="mt-12 w-full grid grid-cols-3 gap-3">
            <Button
              variant="outline"
              className="border-white/10 h-16 flex flex-col items-center justify-center gap-1 hover:bg-white/5"
              onClick={() => updateHydration(250)}
            >
              <span className="text-xs font-bold text-secondary-foreground">
                <Plus className="w-3 h-3 inline mr-1" />
                250
              </span>
              <span className="text-[10px] uppercase tracking-widest text-secondary-foreground/60">
                Glass
              </span>
            </Button>
            <Button
              variant="outline"
              className="border-white/10 h-16 flex flex-col items-center justify-center gap-1 hover:bg-white/5"
              onClick={() => updateHydration(500)}
            >
              <span className="text-xs font-bold text-white">
                <Plus className="w-3 h-3 inline mr-1" />
                500
              </span>
              <span className="text-[10px] uppercase tracking-widest text-secondary-foreground/60">
                Bottle
              </span>
            </Button>
            <Button
              variant="outline"
              className="border-white/10 h-16 flex flex-col items-center justify-center gap-1 hover:bg-white/5"
              onClick={() => updateHydration(750)}
            >
              <span className="text-xs font-bold text-white">
                <Plus className="w-3 h-3 inline mr-1" />
                750
              </span>
              <span className="text-[10px] uppercase tracking-widest text-secondary-foreground/60">
                Shaker
              </span>
            </Button>
          </div>

          <div className="mt-4 w-full flex gap-3">
            <Button
              variant="ghost"
              className="flex-1 text-red-400 hover:text-red-400 hover:bg-red-400/10 text-xs font-bold uppercase tracking-widest"
              onClick={() => updateHydration(-250)}
              disabled={currentAmount === 0}
            >
              <Minus className="w-3 h-3 mr-2" /> Remove 250ml
            </Button>
          </div>
        </Card>

        <Card className="glass-card border-white/10">
          <CardHeader>
            <CardTitle className="text-sm font-bold uppercase tracking-widest text-secondary-foreground">
              7-Day History
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[350px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData} margin={{ top: 20, right: 0, left: -20, bottom: 0 }}>
                  <XAxis
                    dataKey="date"
                    stroke="#a0a0a0"
                    fontSize={12}
                    tickLine={false}
                    axisLine={false}
                    dy={10}
                  />
                  <YAxis
                    stroke="#a0a0a0"
                    fontSize={12}
                    tickLine={false}
                    axisLine={false}
                    dx={-10}
                  />
                  <Tooltip
                    cursor={{ fill: "rgba(255,255,255,0.05)" }}
                    contentStyle={{
                      backgroundColor: "#111",
                      borderColor: "rgba(255,255,255,0.1)",
                      borderRadius: "8px",
                    }}
                    itemStyle={{ color: "#fff", fontWeight: "bold" }}
                    formatter={(value: number) => [`${value} ml`, "Intake"]}
                  />
                  <Bar dataKey="amount" radius={[4, 4, 0, 0]}>
                    {chartData.map((entry, index) => (
                      <Cell
                        key={`cell-${index}`}
                        fill={entry.amount >= entry.goal ? "#ffffff" : "rgba(255,255,255,0.3)"}
                      />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
