import React, { type ComponentType } from "react";
import { Route, Redirect, type RouteProps } from "wouter";
import { useAuth } from "../contexts/AuthContext";

interface ProtectedRouteProps extends Omit<RouteProps, "component"> {
  component: ComponentType<Record<string, string | undefined>>;
}

export default function ProtectedRoute({ component: Component, ...rest }: ProtectedRouteProps) {
  const { user, loading } = useAuth();

  return (
    <Route {...rest}>
      {(params) => {
        if (loading) {
          return (
            <div className="flex items-center justify-center min-h-[50vh]">
              <div className="animate-pulse text-secondary-foreground">LOADING...</div>
            </div>
          );
        }

        if (!user) {
          return <Redirect to="/login" />;
        }

        return <Component {...params} />;
      }}
    </Route>
  );
}
