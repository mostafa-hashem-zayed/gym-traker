import React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "./ui/button";

interface WorkoutModeBarProps {
  active: boolean;
  progress: number;
  total: number;
  onFinish: () => void;
  onCancel: () => void;
}

export default function WorkoutModeBar({ active, progress, total, onFinish, onCancel }: WorkoutModeBarProps) {
  return (
    <AnimatePresence>
      {active && (
        <motion.div
          initial={{ y: "100%" }}
          animate={{ y: 0 }}
          exit={{ y: "100%" }}
          className="fixed bottom-0 left-0 right-0 border-t border-white/10 bg-[#0a0a0a]/90 backdrop-blur-xl z-50 p-4"
        >
          <div className="container mx-auto max-w-4xl flex items-center justify-between gap-4">
            <div className="flex-1">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-bold tracking-widest text-secondary-foreground uppercase">Workout Progress</span>
                <span className="text-sm font-bold">{progress} / {total}</span>
              </div>
              <div className="h-2 w-full bg-white/10 rounded-full overflow-hidden">
                <motion.div 
                  className="h-full bg-white rounded-full"
                  initial={{ width: 0 }}
                  animate={{ width: `${(progress / total) * 100}%` }}
                />
              </div>
            </div>
            <div className="flex gap-2 shrink-0">
              <Button variant="ghost" className="text-secondary-foreground" onClick={onCancel}>
                CANCEL
              </Button>
              <Button onClick={onFinish} disabled={progress === 0} className="bg-white text-black hover:bg-white/90 font-bold">
                FINISH
              </Button>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
