import React, { useState } from "react";
import { Play, Check } from "lucide-react";
import YouTubeModal from "./YouTubeModal";
import { cn } from "../lib/utils";

interface ExerciseCardProps {
  exercise: {
    id: string;
    name: string;
    sets: string;
    reps: string;
    youtubeId: string;
  };
  workoutMode?: boolean;
  completed?: boolean;
  onToggleComplete?: () => void;
}

export default function ExerciseCard({ exercise, workoutMode, completed, onToggleComplete }: ExerciseCardProps) {
  const [modalOpen, setModalOpen] = useState(false);

  return (
    <>
      <div className={cn(
        "glass-card rounded-lg overflow-hidden flex gap-4 p-3 transition-colors",
        completed && "opacity-50 grayscale"
      )}>
        <div 
          className="relative w-24 h-24 rounded-md overflow-hidden bg-muted cursor-pointer shrink-0 group"
          onClick={() => setModalOpen(true)}
        >
          <img 
            src={`https://img.youtube.com/vi/${exercise.youtubeId}/hqdefault.jpg`} 
            alt={exercise.name}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
            <Play className="w-8 h-8 text-white fill-white" />
          </div>
        </div>
        
        <div className="flex-1 flex flex-col justify-center">
          <h4 className="font-bold text-lg leading-tight mb-1">{exercise.name}</h4>
          <p className="text-secondary-foreground text-sm font-medium tracking-wide">
            {exercise.sets} SETS × {exercise.reps} REPS
          </p>
        </div>

        {workoutMode && onToggleComplete && (
          <div className="flex items-center justify-center px-4">
            <button
              onClick={onToggleComplete}
              className={cn(
                "w-8 h-8 rounded-full border-2 flex items-center justify-center transition-colors",
                completed 
                  ? "bg-success border-success text-black" 
                  : "border-white/20 hover:border-white/40 text-transparent"
              )}
            >
              <Check className="w-5 h-5" />
            </button>
          </div>
        )}
      </div>

      <YouTubeModal 
        open={modalOpen} 
        onOpenChange={setModalOpen} 
        youtubeId={exercise.youtubeId} 
      />
    </>
  );
}
