import React from "react";
import { motion } from "framer-motion";

interface HydrationCircleProps {
  amount: number;
  goal: number;
  size?: number;
}

export default function HydrationCircle({ amount, goal, size = 200 }: HydrationCircleProps) {
  const strokeWidth = 12;
  const radius = (size - strokeWidth) / 2;
  const circumference = radius * 2 * Math.PI;
  const safeGoal = Math.max(goal, 1);
  const percent = Math.min(amount / safeGoal, 1);
  const strokeDashoffset = circumference - percent * circumference;

  return (
    <div className="relative flex items-center justify-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="transform -rotate-90">
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke="rgba(255,255,255,0.1)"
          strokeWidth={strokeWidth}
          fill="none"
        />
        <motion.circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke="#fff"
          strokeWidth={strokeWidth}
          fill="none"
          strokeLinecap="round"
          initial={{ strokeDashoffset: circumference }}
          animate={{ strokeDashoffset }}
          transition={{ duration: 1, ease: "easeOut" }}
          style={{ strokeDasharray: circumference }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
        <span className="text-4xl font-black tracking-tighter">
          {(amount / 1000).toFixed(1)}<span className="text-xl text-secondary-foreground">L</span>
        </span>
        <span className="text-sm font-semibold tracking-widest text-secondary-foreground uppercase mt-1">
          / {(goal / 1000).toFixed(1)}L GOAL
        </span>
      </div>
    </div>
  );
}
