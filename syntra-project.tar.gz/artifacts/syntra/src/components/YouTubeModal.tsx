import React from "react";
import { Dialog, DialogContent, DialogTitle } from "./ui/dialog";

interface YouTubeModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  youtubeId: string;
}

export default function YouTubeModal({ open, onOpenChange, youtubeId }: YouTubeModalProps) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl w-[90vw] p-0 border-0 bg-transparent shadow-none overflow-hidden aspect-video">
        <DialogTitle className="sr-only">Exercise Video</DialogTitle>
        {open && (
          <iframe
            className="w-full h-full"
            src={`https://www.youtube.com/embed/${youtubeId}?autoplay=1`}
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
          />
        )}
      </DialogContent>
    </Dialog>
  );
}
