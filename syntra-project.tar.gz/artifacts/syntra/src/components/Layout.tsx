import React from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "../contexts/AuthContext";
import { signOutUser } from "../lib/auth";
import { Button } from "./ui/button";
import { Activity, Dumbbell, Scale, Droplet, History } from "lucide-react";
import CoachChat from "./CoachChat";

export default function Layout({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth();
  const [location] = useLocation();

  const mobileNavItems = [
    { href: "/dashboard", label: "Dashboard", Icon: Activity },
    { href: "/programs", label: "Programs", Icon: Dumbbell },
    { href: "/weight", label: "Weight", Icon: Scale },
    { href: "/hydration", label: "Hydration", Icon: Droplet },
    { href: "/workout", label: "History", Icon: History },
  ];

  return (
    <div className="min-h-[100dvh] flex flex-col bg-background text-foreground">
      <header className="sticky top-0 z-50 w-full border-b border-white/5 bg-[#0a0a0a]/80 backdrop-blur-md">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <Link href="/" className="text-xl font-black tracking-widest text-white">
            SYNTRA
          </Link>
          
          <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-secondary-foreground">
            <Link href="/programs" className="hover:text-white transition-colors">PROGRAMS</Link>
            {user && (
              <>
                <Link href="/dashboard" className="hover:text-white transition-colors">DASHBOARD</Link>
                <Link href="/workout" className="hover:text-white transition-colors">WORKOUTS</Link>
                <Link href="/weight" className="hover:text-white transition-colors">WEIGHT</Link>
                <Link href="/hydration" className="hover:text-white transition-colors">HYDRATION</Link>
              </>
            )}
          </nav>

          <div className="flex items-center gap-4">
            {!loading && (
              user ? (
                <div className="flex items-center gap-4">
                  <span className="text-sm text-secondary-foreground hidden md:inline-block">
                    {user.email}
                  </span>
                  <Button variant="outline" className="border-white/10" onClick={signOutUser}>
                    LOGOUT
                  </Button>
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <Link href="/login">
                    <Button variant="ghost" className="border-transparent text-secondary-foreground hover:text-white">
                      LOGIN
                    </Button>
                  </Link>
                  <Link href="/signup">
                    <Button className="bg-white text-black hover:bg-white/90">
                      SIGN UP
                    </Button>
                  </Link>
                </div>
              )
            )}
          </div>
        </div>
      </header>

      <main className={`flex-1 flex flex-col${user ? " pb-16 md:pb-0" : ""}`}>
        {children}
      </main>

      <CoachChat />

      {user && (
        <nav className="fixed bottom-0 left-0 right-0 z-50 md:hidden border-t border-white/10 bg-[#0a0a0a]/95 backdrop-blur-xl">
          <div className="flex items-center justify-around h-16">
            {mobileNavItems.map(({ href, label, Icon }) => {
              const active = location === href;
              return (
                <Link
                  key={href}
                  href={href}
                  className={`flex flex-col items-center gap-1 px-3 transition-colors ${
                    active ? "text-white" : "text-secondary-foreground hover:text-white"
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  <span className="text-[9px] font-bold uppercase tracking-widest">{label}</span>
                </Link>
              );
            })}
          </div>
        </nav>
      )}
    </div>
  );
}
