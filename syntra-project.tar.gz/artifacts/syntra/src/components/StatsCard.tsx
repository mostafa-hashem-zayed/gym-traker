import React from "react";
import { Card, CardContent } from "./ui/card";

interface StatsCardProps {
  label: string;
  value: string | number;
  subValue?: string;
  trend?: "up" | "down" | "neutral";
}

export default function StatsCard({ label, value, subValue, trend }: StatsCardProps) {
  return (
    <Card className="glass-card">
      <CardContent className="p-6">
        <p className="text-xs font-semibold tracking-wider text-secondary-foreground uppercase mb-2">
          {label}
        </p>
        <div className="flex items-baseline gap-2">
          <span className="text-3xl font-black tracking-tight">{value}</span>
          {subValue && (
            <span className="text-sm font-medium text-secondary-foreground">
              {subValue}
            </span>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
