import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider } from "@/contexts/AuthContext";
import Layout from "@/components/Layout";
import ProtectedRoute from "@/components/ProtectedRoute";

import Home from "@/pages/Home";
import Login from "@/pages/Login";
import Signup from "@/pages/Signup";
import Dashboard from "@/pages/Dashboard";
import Programs from "@/pages/Programs";
import ProgramDetail from "@/pages/ProgramDetail";
import WorkoutDay from "@/pages/WorkoutDay";
import Weight from "@/pages/Weight";
import WorkoutHistory from "@/pages/WorkoutHistory";
import Hydration from "@/pages/Hydration";
import NotFound from "@/pages/not-found";

const queryClient = new QueryClient();

function Router() {
  return (
    <Layout>
      <Switch>
        <Route path="/" component={Home} />
        <Route path="/login" component={Login} />
        <Route path="/signup" component={Signup} />
        <Route path="/programs" component={Programs} />
        <Route path="/programs/:programId" component={ProgramDetail} />
        <Route path="/programs/:programId/:dayId" component={WorkoutDay} />
        <ProtectedRoute path="/dashboard" component={Dashboard} />
        <ProtectedRoute path="/weight" component={Weight} />
        <ProtectedRoute path="/workout" component={WorkoutHistory} />
        <ProtectedRoute path="/hydration" component={Hydration} />
        <Route component={NotFound} />
      </Switch>
    </Layout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <TooltipProvider>
          <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
            <Router />
          </WouterRouter>
          <Toaster />
        </TooltipProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
