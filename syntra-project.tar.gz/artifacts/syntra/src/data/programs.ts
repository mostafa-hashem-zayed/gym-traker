export const PROGRAMS = [
  {
    id: "full-body",
    name: "Full Body",
    description: "Two comprehensive full-body sessions covering all major muscle groups.",
    days: 2,
    frequency: "2x/week",
    difficulty: "Beginner–Intermediate",
    workouts: [
      {
        id: "day1",
        name: "Day 1",
        exercises: [
          { id: "incline-smith-press", name: "Incline Smith Press", sets: "2", reps: "6–8", youtubeId: "hLbOCm0IGzU" },
          { id: "pull-up-lat-pulldown", name: "Pull-Up / Lat Pulldown", sets: "2", reps: "6–8", youtubeId: "eGo4IYlbE5g" },
          { id: "hack-squat", name: "Hack Squat", sets: "2", reps: "8–10", youtubeId: "0tn5K9NlCfo" },
          { id: "romanian-deadlift", name: "Romanian Deadlift", sets: "2", reps: "6–8", youtubeId: "JCXUYuzwNrM" },
          { id: "lateral-raise", name: "Cable / Dumbbell Lateral Raise", sets: "2", reps: "6–8", youtubeId: "3VcKaXpzqRo" },
          { id: "overhead-cable-ext", name: "Overhead Cable Extension", sets: "2", reps: "8–10", youtubeId: "kjpPMtbdejc" },
          { id: "ez-bar-curl", name: "EZ Bar Curl", sets: "2", reps: "8–10", youtubeId: "zG2xJ0Q5QtI" },
          { id: "standing-calf-raise", name: "Standing Calf Raise", sets: "2", reps: "8–10", youtubeId: "gwLzBJYoWlI" },
        ]
      },
      {
        id: "day2",
        name: "Day 2",
        exercises: [
          { id: "lower-chest-cable-fly", name: "Lower Chest Cable Fly", sets: "2", reps: "8–10", youtubeId: "eozdVDA78K0" },
          { id: "t-bar-row", name: "T-Bar Row", sets: "2", reps: "6–8", youtubeId: "j3Igk5nyZE4" },
          { id: "leg-press-bulgarian", name: "Leg Press / Bulgarian Split Squat", sets: "2", reps: "8–10", youtubeId: "IZxyjW7MPJQ" },
          { id: "lying-leg-curl", name: "Seated or Lying Leg Curl", sets: "2", reps: "8–10", youtubeId: "1Tq3QdYUuHs" },
          { id: "rear-delt-fly", name: "Rear Delt Fly / Shoulder Press Machine", sets: "2", reps: "6–8", youtubeId: "Z6n63am5tYs" },
          { id: "rope-pushdown", name: "Rope Pushdown / Skull Crusher", sets: "2", reps: "8–10", youtubeId: "vB5OHsJ3EME" },
          { id: "hammer-curl", name: "Hammer Curl / Bayesian Curl", sets: "2", reps: "8–10", youtubeId: "TwD-YGVP4Bk" },
          { id: "seated-calf-raise", name: "Seated Calf Raise / Cable Crunch", sets: "2", reps: "8–10", youtubeId: "OtZahKGb1dA" },
        ]
      }
    ]
  },
  {
    id: "upper-lower",
    name: "Upper / Lower",
    description: "Four-day split alternating upper and lower body for balanced development.",
    frequency: "4x/week",
    difficulty: "Intermediate",
    workouts: [
      {
        id: "upper-a",
        name: "Upper A",
        exercises: [
          { id: "incline-smith-press", name: "Incline Smith Press", sets: "2", reps: "6–8", youtubeId: "hLbOCm0IGzU" },
          { id: "pull-up-lat-pulldown", name: "Pull-Up / Lat Pulldown", sets: "2", reps: "6–8", youtubeId: "eGo4IYlbE5g" },
          { id: "chest-supported-row", name: "Chest Supported Row", sets: "2", reps: "6–8", youtubeId: "PiPL-MZrGGw" },
          { id: "lateral-raise", name: "Cable / Dumbbell Lateral Raise", sets: "2", reps: "6–8", youtubeId: "3VcKaXpzqRo" },
          { id: "overhead-cable-ext", name: "Overhead Cable Ext / Bayesian Curl", sets: "2", reps: "8–10", youtubeId: "kjpPMtbdejc" },
        ]
      },
      {
        id: "lower-a",
        name: "Lower A",
        exercises: [
          { id: "hack-squat", name: "Hack Squat", sets: "2", reps: "8–10", youtubeId: "0tn5K9NlCfo" },
          { id: "romanian-deadlift", name: "Romanian Deadlift", sets: "2", reps: "6–8", youtubeId: "JCXUYuzwNrM" },
          { id: "leg-press", name: "Leg Press", sets: "2", reps: "8–10", youtubeId: "IZxyjW7MPJQ" },
          { id: "seated-leg-curl", name: "Seated Leg Curl", sets: "2", reps: "8–10", youtubeId: "1Tq3QdYUuHs" },
          { id: "standing-calf-raise", name: "Standing Calf Raise / Cable Crunch", sets: "2", reps: "8–10", youtubeId: "gwLzBJYoWlI" },
        ]
      },
      {
        id: "upper-b",
        name: "Upper B",
        exercises: [
          { id: "lower-chest-cable-fly", name: "Lower Chest Cable Fly", sets: "2", reps: "8–10", youtubeId: "eozdVDA78K0" },
          { id: "t-bar-row", name: "T-Bar Row", sets: "2", reps: "6–8", youtubeId: "j3Igk5nyZE4" },
          { id: "shoulder-press-machine", name: "Shoulder Press Machine", sets: "2", reps: "6–8", youtubeId: "Z6n63am5tYs" },
          { id: "rear-delt-fly", name: "Rear Delt Fly", sets: "2", reps: "6–8", youtubeId: "Z6n63am5tYs" },
          { id: "rope-pushdown", name: "Rope Pushdown / EZ Bar Curl", sets: "2", reps: "8–10", youtubeId: "vB5OHsJ3EME" },
        ]
      },
      {
        id: "lower-b",
        name: "Lower B",
        exercises: [
          { id: "bulgarian-split-squat", name: "Bulgarian Split Squat", sets: "2", reps: "8–10", youtubeId: "IZxyjW7MPJQ" },
          { id: "lying-leg-curl", name: "Lying Leg Curl", sets: "2", reps: "8–10", youtubeId: "1Tq3QdYUuHs" },
          { id: "romanian-deadlift", name: "Romanian Deadlift / Smith RDL", sets: "2", reps: "6–8", youtubeId: "JCXUYuzwNrM" },
          { id: "leg-extension", name: "Leg Extension", sets: "2", reps: "8–10", youtubeId: "YyvSfVjQeL0" },
          { id: "seated-calf-raise", name: "Seated Calf Raise / Hanging Leg Raise", sets: "2", reps: "8–10", youtubeId: "OtZahKGb1dA" },
        ]
      }
    ]
  },
  {
    id: "push-pull-legs",
    name: "Push Pull Legs",
    description: "Classic 5–6 day PPL split for maximum volume and hypertrophy.",
    frequency: "5–6x/week",
    difficulty: "Intermediate–Advanced",
    workouts: [
      {
        id: "push",
        name: "Push",
        exercises: [
          { id: "incline-smith-press", name: "Incline Smith Press", sets: "2", reps: "6–8", youtubeId: "hLbOCm0IGzU" },
          { id: "lower-chest-cable-fly", name: "Lower Chest Cable Fly", sets: "2", reps: "8–10", youtubeId: "eozdVDA78K0" },
          { id: "shoulder-press-machine", name: "Shoulder Press Machine", sets: "2", reps: "6–8", youtubeId: "Z6n63am5tYs" },
          { id: "lateral-raise", name: "Cable / Dumbbell Lateral Raise", sets: "2", reps: "6–8", youtubeId: "3VcKaXpzqRo" },
          { id: "overhead-cable-ext", name: "Overhead Cable Extension", sets: "2", reps: "8–10", youtubeId: "kjpPMtbdejc" },
        ]
      },
      {
        id: "pull",
        name: "Pull",
        exercises: [
          { id: "pull-up-lat-pulldown", name: "Pull-Up / Lat Pulldown", sets: "2", reps: "6–8", youtubeId: "eGo4IYlbE5g" },
          { id: "t-bar-row", name: "T-Bar Row", sets: "2", reps: "6–8", youtubeId: "j3Igk5nyZE4" },
          { id: "chest-supported-row", name: "Chest Supported Row", sets: "2", reps: "6–8", youtubeId: "PiPL-MZrGGw" },
          { id: "rear-delt-fly", name: "Rear Delt Fly", sets: "2", reps: "6–8", youtubeId: "Z6n63am5tYs" },
          { id: "ez-bar-curl", name: "EZ Bar Curl", sets: "2", reps: "8–10", youtubeId: "zG2xJ0Q5QtI" },
        ]
      },
      {
        id: "legs",
        name: "Legs",
        exercises: [
          { id: "hack-squat", name: "Hack Squat", sets: "2", reps: "8–10", youtubeId: "0tn5K9NlCfo" },
          { id: "romanian-deadlift", name: "Romanian Deadlift", sets: "2", reps: "6–8", youtubeId: "JCXUYuzwNrM" },
          { id: "leg-press-bulgarian", name: "Leg Press / Bulgarian Split Squat", sets: "2", reps: "8–10", youtubeId: "IZxyjW7MPJQ" },
          { id: "lying-leg-curl", name: "Seated or Lying Leg Curl", sets: "2", reps: "8–10", youtubeId: "1Tq3QdYUuHs" },
          { id: "calf-raise", name: "Standing or Seated Calf Raise", sets: "2", reps: "8–10", youtubeId: "gwLzBJYoWlI" },
        ]
      }
    ]
  },
  {
    id: "arnold-split",
    name: "Arnold Split",
    description: "Six-day Arnold split — chest & back, shoulders & arms, legs for maximum intensity.",
    frequency: "6x/week",
    difficulty: "Advanced",
    workouts: [
      {
        id: "chest-back",
        name: "Chest + Back",
        exercises: [
          { id: "incline-smith-press", name: "Incline Smith Press", sets: "2", reps: "6–8", youtubeId: "hLbOCm0IGzU" },
          { id: "lower-chest-cable-fly", name: "Lower Chest Cable Fly", sets: "2", reps: "8–10", youtubeId: "eozdVDA78K0" },
          { id: "pull-up-lat-pulldown", name: "Pull-Up / Lat Pulldown", sets: "2", reps: "6–8", youtubeId: "eGo4IYlbE5g" },
          { id: "t-bar-row", name: "T-Bar Row", sets: "2", reps: "6–8", youtubeId: "j3Igk5nyZE4" },
          { id: "chest-supported-row", name: "Chest Supported Row", sets: "2", reps: "6–8", youtubeId: "PiPL-MZrGGw" },
        ]
      },
      {
        id: "shoulders-arms",
        name: "Shoulders + Arms",
        exercises: [
          { id: "shoulder-press-machine", name: "Shoulder Press Machine", sets: "2", reps: "6–8", youtubeId: "Z6n63am5tYs" },
          { id: "lateral-raise", name: "Cable / Dumbbell Lateral Raise", sets: "2", reps: "6–8", youtubeId: "3VcKaXpzqRo" },
          { id: "rear-delt-fly", name: "Rear Delt Fly", sets: "2", reps: "6–8", youtubeId: "Z6n63am5tYs" },
          { id: "overhead-cable-ext", name: "Overhead Cable Ext / Rope Pushdown", sets: "2", reps: "8–10", youtubeId: "kjpPMtbdejc" },
          { id: "ez-bar-curl", name: "EZ Bar Curl / Hammer Curl", sets: "2", reps: "8–10", youtubeId: "zG2xJ0Q5QtI" },
        ]
      },
      {
        id: "legs",
        name: "Legs",
        exercises: [
          { id: "hack-squat", name: "Hack Squat", sets: "2", reps: "8–10", youtubeId: "0tn5K9NlCfo" },
          { id: "romanian-deadlift", name: "Romanian Deadlift", sets: "2", reps: "6–8", youtubeId: "JCXUYuzwNrM" },
          { id: "bulgarian-split-squat", name: "Bulgarian Split Squat", sets: "2", reps: "8–10", youtubeId: "IZxyjW7MPJQ" },
          { id: "lying-leg-curl", name: "Seated or Lying Leg Curl", sets: "2", reps: "8–10", youtubeId: "1Tq3QdYUuHs" },
          { id: "calf-raise", name: "Seated or Standing Calf Raise", sets: "2", reps: "8–10", youtubeId: "gwLzBJYoWlI" },
        ]
      }
    ]
  }
];
