import { Router } from "express";
import { openrouter } from "@workspace/integrations-openrouter-ai";

const router = Router();

const SYSTEM_PROMPT = `You are SYNTRA Coach, a premium AI fitness assistant built into the SYNTRA training platform. You are knowledgeable, motivating, and precise.

You help athletes with:
- Exercise technique and form explanations
- Hypertrophy, strength, and recovery science
- Hydration and nutrition fundamentals
- Training concepts: progressive overload, periodization, volume, intensity
- Beginner guidance and motivation
- Rest, sleep, and recovery optimization

You do NOT:
- Generate complete multi-week workout programs
- Modify or interact with the user's training logs or database
- Provide medical diagnoses or injury treatment plans

Respond concisely and with authority. Be direct and motivating. Use precise fitness terminology. Keep responses focused — use bullet points when listing multiple items. Aim for clarity over length.`;

interface ChatMessage {
  role: "user" | "assistant";
  content: string;
}

router.post("/coach", async (req, res) => {
  const { messages } = req.body as { messages: ChatMessage[] };

  if (!Array.isArray(messages) || messages.length === 0) {
    res.status(400).json({ error: "messages array is required" });
    return;
  }

  const sanitized = messages
    .filter((m) => m.role === "user" || m.role === "assistant")
    .map((m) => ({ role: m.role, content: String(m.content).slice(0, 4000) }))
    .slice(-20);

  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");
  res.setHeader("Access-Control-Allow-Origin", "*");

  try {
    const stream = await openrouter.chat.completions.create({
      model: "meta-llama/llama-3.3-70b-instruct",
      max_tokens: 8192,
      messages: [
        { role: "system", content: SYSTEM_PROMPT },
        ...sanitized,
      ],
      stream: true,
    });

    for await (const chunk of stream) {
      const content = chunk.choices[0]?.delta?.content;
      if (content) {
        res.write(`data: ${JSON.stringify({ content })}\n\n`);
      }
    }

    res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
    res.end();
  } catch (err: any) {
    req.log.error({ err }, "Coach streaming error");
    res.write(`data: ${JSON.stringify({ error: "Failed to get response. Please try again." })}\n\n`);
    res.end();
  }
});

export default router;
