# Changelog

All notable changes to this project are documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).

## [Unreleased]

### Changed
- Firebase client configuration now loads from environment variables instead
  of being hardcoded in source, with an accompanying `.env.example`.
- Repository prepared for public/professional GitHub distribution: added
  README, LICENSE (MIT), CONTRIBUTING guide, and this changelog.

## [0.3.0]

### Added
- **SYNTRA Coach** — floating AI fitness chat assistant powered by OpenRouter
  (Llama 3.3 70B), with streaming responses via Server-Sent Events.
- `POST /api/coach` endpoint on the API server dedicated to the coach feature.

## [0.2.0]

### Fixed
- Date parsing bugs affecting workout history.
- Streak calculation accuracy across week/month boundaries.
- Firestore permission errors for authenticated users.
- Mobile navigation layout issues.

## [0.1.0]

### Added
- Initial SYNTRA app: Firebase Authentication, Firestore-backed data model.
- Dashboard, Weight tracking, Hydration tracking, Workout History pages.
- Training Programs and per-day Workout pages with exercise demo videos.
- Mobile-first responsive navigation.
- Installable PWA support.
