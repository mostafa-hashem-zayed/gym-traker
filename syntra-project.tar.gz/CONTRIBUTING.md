# Contributing to SYNTRA

Thanks for your interest in improving SYNTRA! This document covers how the
repository is organized and how to get a change merged.

## Getting Started

1. Fork the repository and clone your fork.
2. Install dependencies: `pnpm install`.
3. Copy the environment templates and fill in your own credentials:
   ```bash
   cp artifacts/syntra/.env.example artifacts/syntra/.env
   cp artifacts/api-server/.env.example artifacts/api-server/.env
   ```
4. Run the app locally (see the **How to Run the Project** section of the
   [README](README.md)).

## Development Workflow

- This repo is a **pnpm workspace monorepo**. Each deployable app lives under
  `artifacts/`, and shared code lives under `lib/`.
- Prefer adding shared logic to a `lib/*` package over duplicating it across
  artifacts.
- Keep pull requests focused — one feature or fix per PR.
- Run `pnpm run typecheck` before opening a PR; it must pass with no errors.
- Follow the existing code style (Prettier is configured at the repo root —
  run `npx prettier --write .` if unsure).

## Commit Messages

Use clear, present-tense messages, e.g.:

```
Add hydration goal editing to Settings page
Fix streak calculation off-by-one on week boundaries
```

## Submitting a Pull Request

1. Create a branch off `main`: `git checkout -b feat/short-description`.
2. Make your changes, with tests/manual verification where applicable.
3. Update `CHANGELOG.md` under an "Unreleased" section if your change is
   user-facing.
4. Open a PR describing **what** changed and **why**. Screenshots are
   appreciated for UI changes.

## Reporting Issues

Please include:
- Steps to reproduce
- Expected vs. actual behavior
- Screenshots or console/network logs if relevant
- Browser/OS if it's a UI issue

## Code of Conduct

Be respectful and constructive. We're all here to make the project better.
